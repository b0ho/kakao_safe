package com.sweettracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZoommaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZoommaApplication.class, args);
	}
}

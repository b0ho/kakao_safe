# kakaoAutoReplyExample
Using Kakaotalk auto reply API 

카카오톡 플러스친구 자동응답 API를 이용한 간단한 챗봇 샘플입니다. 
소스 설명은 http://annajinee.tistory.com/m/19 참고 바랍니다. 


상세 API 기술서는 https://github.com/plusfriend/auto_reply에서 보실 수 있습니다. 
